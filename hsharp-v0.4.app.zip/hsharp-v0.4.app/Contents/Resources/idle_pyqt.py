import sys
import os
import json
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtGui import QFont, QColor, QTextFormat, QTextCharFormat, QSyntaxHighlighter, QTextCursor, QPixmap
from PyQt5.QtCore import QRect, QRegExp
from PyQt5.QtWidgets import QDockWidget, QLineEdit

from lexer import Lexer
from parser import Parser
from interpreter import Interpreter
from compiler import Compiler
from bytecode import VM


class EmittingStream(QtCore.QObject):
    textWritten = QtCore.pyqtSignal(str)
    def write(self, text):
        if not text:
            return
        # Schedule emission via the Qt event loop to avoid calling
        # into signal handlers directly from arbitrary Python code
        # and prevent exceptions from propagating into PyQt internals.
        try:
            QtCore.QTimer.singleShot(0, lambda t=str(text): self.textWritten.emit(t))
        except Exception:
            try:
                self.textWritten.emit(str(text))
            except Exception:
                import traceback
                sys.__stderr__.write(traceback.format_exc())

    def flush(self):
        pass


class IDLEWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('H# interpreter IDLE')
        self.resize(900, 600)

        central = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(central)

        self.editor = CodeEditor()
        font = QFont('Consolas' if sys.platform == 'win32' else 'Menlo')
        font.setPointSize(12)
        self.editor.setFont(font)

        btn_layout = QtWidgets.QHBoxLayout()
        self.open_btn = QtWidgets.QPushButton('Open')
        self.save_btn = QtWidgets.QPushButton('Save')
        self.run_btn = QtWidgets.QPushButton('Run Source')
        self.run_sel_btn = QtWidgets.QPushButton('Run Selection')
        self.emit_btn = QtWidgets.QPushButton('Compile .hbc')
        self.runbc_btn = QtWidgets.QPushButton('Run .hbc')
        self.syntax_btn = QtWidgets.QPushButton('Syntax Check')
        self.clear_btn = QtWidgets.QPushButton('Clear Output')
        self.stop_btn = QtWidgets.QPushButton('Stop')

        for b in (self.open_btn, self.save_btn, self.run_btn, self.run_sel_btn, self.emit_btn, self.runbc_btn, self.syntax_btn, self.clear_btn, self.stop_btn):
            btn_layout.addWidget(b)

        self.output = QtWidgets.QPlainTextEdit()
        self.output.setReadOnly(True)
        out_font = self.output.font()
        out_font.setPointSize(11)
        self.output.setFont(out_font)

        layout.addLayout(btn_layout)
        layout.addWidget(self.editor)
        layout.addWidget(QtWidgets.QLabel('Output:'))
        layout.addWidget(self.output)

        self.setCentralWidget(central)

        # menu bar
        menubar = self.menuBar()
        file_menu = menubar.addMenu('File')
        run_menu = menubar.addMenu('Run')
        build_menu = menubar.addMenu('Build')
        tools_menu = menubar.addMenu('Tools')

        # File actions
        open_action = QtWidgets.QAction('Open', self)
        save_action = QtWidgets.QAction('Save', self)
        open_action.triggered.connect(self.open_file)
        save_action.triggered.connect(self.save_file)
        file_menu.addAction(open_action)
        file_menu.addAction(save_action)

        # Run actions
        run_action = QtWidgets.QAction('Run Source', self)
        run_sel_action = QtWidgets.QAction('Run Selection', self)
        run_bc_action = QtWidgets.QAction('Run .hbc', self)
        stop_action = QtWidgets.QAction('Stop', self)
        run_action.triggered.connect(self.run_source)
        run_sel_action.triggered.connect(self.run_selection)
        run_bc_action.triggered.connect(self.run_bc_file)
        stop_action.triggered.connect(self.stop_process)
        run_menu.addAction(run_action)
        run_menu.addAction(run_sel_action)
        run_menu.addAction(run_bc_action)
        run_menu.addAction(stop_action)

        # Build actions
        emit_action = QtWidgets.QAction('Compile .hbc', self)
        emit_action.triggered.connect(self.compile_bc)
        build_menu.addAction(emit_action)

        # Tools: Syntax check, Shell, Debug
        syntax_action = QtWidgets.QAction('Syntax Check', self)
        syntax_action.triggered.connect(self.syntax_check)
        tools_menu.addAction(syntax_action)

        self.shell_action = QtWidgets.QAction('Shell Mode', self, checkable=True)
        self.shell_action.triggered.connect(self.toggle_shell)
        tools_menu.addAction(self.shell_action)

        self.debug_action = QtWidgets.QAction('Debug Mode', self, checkable=True)
        self.debug_action.triggered.connect(self.toggle_debug_mode)
        tools_menu.addAction(self.debug_action)
        # connections
        self.open_btn.clicked.connect(self.open_file)
        self.save_btn.clicked.connect(self.save_file)
        self.run_btn.clicked.connect(self.run_source)
        self.run_sel_btn.clicked.connect(self.run_selection)
        self.emit_btn.clicked.connect(self.compile_bc)
        self.runbc_btn.clicked.connect(self.run_bc_file)
        self.syntax_btn.clicked.connect(self.syntax_check)
        self.clear_btn.clicked.connect(self.output.clear)
        self.stop_btn.clicked.connect(self.stop_process)

        self.current_file = None
        self.proc = None
        self.shell_proc = None
        self.shell_dock = None
        self.debug_mode = False

        # redirect stdout
        self.stream = EmittingStream()
        self.stream.textWritten.connect(self.append_output)

    def append_output(self, text):
        try:
            self.output.moveCursor(QTextCursor.End)
            self.output.insertPlainText(text)
        except Exception:
            # Avoid allowing exceptions raised while updating the GUI to
            # bubble into PyQt internals (which can call qFatal).
            import traceback
            sys.__stderr__.write('Exception in append_output:\n')
            sys.__stderr__.write(traceback.format_exc())

    def open_file(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, 'Open H# file', '.', 'H# Files (*.hto);;All Files (*)')
        if path:
            with open(path, 'r', encoding='utf-8') as f:
                self.editor.setPlainText(f.read())
            self.current_file = path

    def save_file(self):
        if not self.current_file:
            path, _ = QtWidgets.QFileDialog.getSaveFileName(self, 'Save H# file', '.', 'H# Files (*.hto)')
            if not path:
                return
            self.current_file = path
        with open(self.current_file, 'w', encoding='utf-8') as f:
            f.write(self.editor.toPlainText())

    def run_source(self):
        # Run current editor content in a subprocess so it can be terminated
        code = self.editor.toPlainText()
        if not code.strip():
            return
        # write to temp file
        import tempfile
        tf = tempfile.NamedTemporaryFile(delete=False, suffix='.hto')
        tf.write(code.encode('utf-8'))
        tf.close()
        cmd = [sys.executable, os.path.join(os.path.dirname(__file__), 'hsharp.py'), tf.name]
        self.start_process(cmd)

    def compile_bc(self):
        code = self.editor.toPlainText()
        self.output.clear()
        old_stdout = sys.stdout
        sys.stdout = self.stream
        try:
            lexer = Lexer(code)
            parser = Parser(lexer)
            program = parser.parse()
            compiler = Compiler()
            bc = compiler.compile(program)
            out = (self.current_file or 'untitled.hto').rsplit('.', 1)[0] + '.hbc'
            with open(out, 'w', encoding='utf-8') as f:
                json.dump(bc, f)
            print(f'Wrote bytecode to {out}')
        except Exception as e:
            print(f'Compilation error: {e}')
        finally:
            sys.stdout = old_stdout

    def run_bc_file(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, 'Open HBC file', '.', 'Bytecode Files (*.hbc);;All Files (*)')
        if not path:
            return
        # run VM via hsharp.py --run-bc for safety
        self.start_process([sys.executable, os.path.join(os.path.dirname(__file__), 'hsharp.py'), '--run-bc', path])

    def syntax_check(self):
        code = self.editor.toPlainText()
        self.output.clear()
        try:
            lexer = Lexer(code)
            parser = Parser(lexer)
            parser.parse()
            print('Syntax OK')
        except Exception as e:
            print(f'Syntax Error: {e}')

    def run_selection(self):
        text = self.editor.textCursor().selectedText()
        if not text.strip():
            return
        import tempfile
        tf = tempfile.NamedTemporaryFile(delete=False, suffix='.hto')
        tf.write(text.encode('utf-8'))
        tf.close()
        cmd = [sys.executable, os.path.join(os.path.dirname(__file__), 'hsharp.py'), tf.name]
        self.start_process(cmd)

    def start_process(self, cmd):
        # ensure previous process stopped
        if self.proc and self.proc.state() != QtCore.QProcess.NotRunning:
            self.proc.kill()
            self.proc = None
        self.output.clear()
        self.proc = QtCore.QProcess(self)
        self.proc.setProcessChannelMode(QtCore.QProcess.MergedChannels)
        self.proc.readyReadStandardOutput.connect(self._read_proc)
        self.proc.readyReadStandardError.connect(self._read_proc)
        self.proc.finished.connect(self._proc_finished)
        try:
            # inject debug flag if enabled
            if self.debug_mode and '--debug' not in cmd:
                cmd = cmd[:1] + ['--debug'] + cmd[1:]
            self.proc.start(cmd[0], cmd[1:])
        except Exception as e:
            print(f'Failed to start process: {e}')

    def _read_proc(self):
        if not self.proc:
            return
        out = bytes(self.proc.readAllStandardOutput()).decode('utf-8', errors='replace')
        if out:
            self.append_output(out)

    def _proc_finished(self, exitCode, exitStatus):
        self.append_output(f"\nProcess finished with code {exitCode}\n")

    def stop_process(self):
        if self.proc and self.proc.state() != QtCore.QProcess.NotRunning:
            self.proc.terminate()
            QtCore.QTimer.singleShot(500, lambda: self.proc.kill())

    # Shell mode: start/stop REPL in a dock widget
    def toggle_shell(self, checked):
        if checked:
            self.open_shell()
        else:
            self.close_shell()

    def open_shell(self):
        if self.shell_dock and not self.shell_dock.isHidden():
            self.shell_dock.show()
            return
        # create dock
        self.shell_dock = QDockWidget('H# Shell', self)
        shell_widget = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(shell_widget)
        self.shell_output = QtWidgets.QPlainTextEdit()
        self.shell_output.setReadOnly(True)
        self.shell_input = QLineEdit()
        v.addWidget(self.shell_output)
        v.addWidget(self.shell_input)
        self.shell_dock.setWidget(shell_widget)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.shell_dock)
        # start REPL process
        self.shell_proc = QtCore.QProcess(self)
        self.shell_proc.setProcessChannelMode(QtCore.QProcess.MergedChannels)
        self.shell_proc.readyReadStandardOutput.connect(self._read_shell)
        self.shell_proc.finished.connect(lambda code, stat: self.shell_output.appendPlainText(f"Shell exited {code}"))
        cmd = [sys.executable, os.path.join(os.path.dirname(__file__), 'hsharp.py')]
        if self.debug_mode:
            cmd = cmd[:1] + ['--debug'] + cmd[1:]
        self.shell_proc.start(cmd[0], cmd[1:])
        self.shell_input.returnPressed.connect(self._send_shell_input)

    def close_shell(self):
        if self.shell_proc and self.shell_proc.state() != QtCore.QProcess.NotRunning:
            self.shell_proc.terminate()
            QtCore.QTimer.singleShot(300, lambda: self.shell_proc.kill())
        if self.shell_dock:
            self.shell_dock.hide()
        self.shell_action.setChecked(False)

    def _read_shell(self):
        if not self.shell_proc:
            return
        out = bytes(self.shell_proc.readAllStandardOutput()).decode('utf-8', errors='replace')
        if out:
            self.shell_output.insertPlainText(out)

    def _send_shell_input(self):
        if not self.shell_proc:
            return
        txt = self.shell_input.text() + '\n'
        try:
            self.shell_proc.write(txt.encode('utf-8'))
        except Exception:
            pass
        self.shell_input.clear()

    def toggle_debug_mode(self, checked):
        self.debug_mode = bool(checked)


class LineNumberArea(QtWidgets.QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.codeEditor = editor

    def sizeHint(self):
        return QtCore.QSize(self.codeEditor.lineNumberAreaWidth(), 0)

    def paintEvent(self, event):
        self.codeEditor.lineNumberAreaPaintEvent(event)


class CodeEditor(QtWidgets.QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.lineNumberArea = LineNumberArea(self)
        self.blockCountChanged.connect(self.updateLineNumberAreaWidth)
        self.updateRequest.connect(self.updateLineNumberArea)
        self.cursorPositionChanged.connect(self.highlightCurrentLine)
        self.updateLineNumberAreaWidth(0)
        self.highlightCurrentLine()
        # attach highlighter
        self.highlighter = HSharpHighlighter(self.document())

    def lineNumberAreaWidth(self):
        digits = 1
        max_block = max(1, self.blockCount())
        while max_block >= 10:
            max_block //= 10
            digits += 1
        space = 3 + self.fontMetrics().width('9') * digits
        return space

    def updateLineNumberAreaWidth(self, _):
        self.setViewportMargins(self.lineNumberAreaWidth(), 0, 0, 0)

    def updateLineNumberArea(self, rect, dy):
        if dy:
            self.lineNumberArea.scroll(0, dy)
        else:
            self.lineNumberArea.update(0, rect.y(), self.lineNumberArea.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.updateLineNumberAreaWidth(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.lineNumberArea.setGeometry(QRect(cr.left(), cr.top(), self.lineNumberAreaWidth(), cr.height()))

    def lineNumberAreaPaintEvent(self, event):
        painter = QtWidgets.QStylePainter(self.lineNumberArea)
        painter.fillRect(event.rect(), QColor(240, 240, 240))
        block = self.firstVisibleBlock()
        blockNumber = block.blockNumber()
        top = self.blockBoundingGeometry(block).translated(self.contentOffset()).top()
        bottom = top + self.blockBoundingRect(block).height()
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(blockNumber + 1)
                painter.setPen(QColor(120, 120, 120))
                painter.drawText(0, int(top), self.lineNumberArea.width()-4, self.fontMetrics().height(), QtCore.Qt.AlignRight, number)
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            blockNumber += 1

    def highlightCurrentLine(self):
        extraSelections = []
        if not self.isReadOnly():
            selection = QtWidgets.QTextEdit.ExtraSelection()
            lineColor = QColor(235, 245, 255)
            selection.format.setBackground(lineColor)
            selection.format.setProperty(QTextFormat.FullWidthSelection, True)
            selection.cursor = self.textCursor()
            selection.cursor.clearSelection()
            extraSelections.append(selection)
        self.setExtraSelections(extraSelections)


class HSharpHighlighter(QSyntaxHighlighter):
    def __init__(self, document):
        super().__init__(document)
        self._rules = []
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor(0, 0, 180))
        keyword_format.setFontWeight(QFont.Bold)
        keywords = [
            'let','fn','return','while','if','else','for','in','print','import',
            'class','extends','new','private','true','false'
        ]
        # logical operators
        keywords.extend(['and', 'or', 'not'])
        for kw in keywords:
            pattern = QRegExp(r"\b" + kw + r"\b")
            self._rules.append((pattern, keyword_format))

        number_format = QTextCharFormat()
        number_format.setForeground(QColor(150, 0, 0))
        self._rules.append((QRegExp(r"\b[0-9]+\b"), number_format))

        string_format = QTextCharFormat()
        string_format.setForeground(QColor(0, 150, 0))
        self._rules.append((QRegExp(r'".*"'), string_format))

        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor(128, 128, 128))
        self._rules.append((QRegExp(r'//.*$'), comment_format))

        # function name / call highlighting (identifier followed by '(')
        func_format = QTextCharFormat()
        func_format.setForeground(QColor(128, 0, 128))
        func_format.setFontItalic(True)
        self._rules.append((QRegExp(r"\b[A-Za-z_][A-Za-z0-9_]*(?=\s*\()"), func_format))

        # Type/Class names (capitalized identifiers)
        type_format = QTextCharFormat()
        type_format.setForeground(QColor(0, 120, 120))
        type_format.setFontWeight(QFont.Bold)
        self._rules.append((QRegExp(r"\b[A-Z][A-Za-z0-9_]*\b"), type_format))

        # Multi-line comment and multi-line string handling
        self.commentStart = QRegExp(r'/\*')
        self.commentEnd = QRegExp(r'\*/')
        self.tripleDoubleStart = QRegExp(r'"""')
        self.tripleDoubleEnd = QRegExp(r'"""')
        self.tripleSingleStart = QRegExp("'''")
        self.tripleSingleEnd = QRegExp("'''")
        self.multiLineStringFormat = string_format
        self.commentFormat = comment_format

    def highlightBlock(self, text):
        for pattern, fmt in self._rules:
            index = pattern.indexIn(text)
            while index >= 0:
                length = pattern.matchedLength()
                self.setFormat(index, length, fmt)
                index = pattern.indexIn(text, index + length)

        # Multi-line comments /* ... */
        self.setCurrentBlockState(0)
        startIndex = 0
        if self.previousBlockState() != 1:
            startIndex = self.commentStart.indexIn(text)
        while startIndex >= 0:
            endIndex = self.commentEnd.indexIn(text, startIndex)
            if endIndex == -1:
                self.setCurrentBlockState(1)
                commentLength = len(text) - startIndex
                self.setFormat(startIndex, commentLength, self.commentFormat)
                break
            else:
                commentLength = endIndex - startIndex + self.commentEnd.matchedLength()
                self.setFormat(startIndex, commentLength, self.commentFormat)
                startIndex = self.commentStart.indexIn(text, startIndex + commentLength)

        # Multi-line triple-double strings
        startIndex = 0
        if self.previousBlockState() != 2:
            startIndex = self.tripleDoubleStart.indexIn(text)
        while startIndex >= 0:
            endIndex = self.tripleDoubleEnd.indexIn(text, startIndex + 3)
            if endIndex == -1:
                self.setCurrentBlockState(2)
                strLen = len(text) - startIndex
                self.setFormat(startIndex, strLen, self.multiLineStringFormat)
                break
            else:
                strLen = endIndex - startIndex + self.tripleDoubleEnd.matchedLength()
                self.setFormat(startIndex, strLen, self.multiLineStringFormat)
                startIndex = self.tripleDoubleStart.indexIn(text, startIndex + strLen)

        # Multi-line triple-single strings
        startIndex = 0
        if self.previousBlockState() != 3:
            startIndex = self.tripleSingleStart.indexIn(text)
        while startIndex >= 0:
            endIndex = self.tripleSingleEnd.indexIn(text, startIndex + 3)
            if endIndex == -1:
                self.setCurrentBlockState(3)
                strLen = len(text) - startIndex
                self.setFormat(startIndex, strLen, self.multiLineStringFormat)
                break
            else:
                strLen = endIndex - startIndex + self.tripleSingleEnd.matchedLength()
                self.setFormat(startIndex, strLen, self.multiLineStringFormat)
                startIndex = self.tripleSingleStart.indexIn(text, startIndex + strLen)


def main():
    app = QtWidgets.QApplication(sys.argv)

    # attempt to show splash from local image file for 3 seconds
    img_path = os.path.join(os.path.dirname(__file__), 'hcs_logo_design2_compressed.jpg')
    if os.path.exists(img_path):
        try:
            pix = QPixmap(img_path)
            if not pix.isNull():
                # scale to a reasonable maximum size while keeping aspect ratio
                max_width = 480
                max_height = 320
                pix = pix.scaled(max_width, max_height, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
                splash = QtWidgets.QSplashScreen(pix)
                splash.setWindowFlags(splash.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
                # center the splash on the primary screen if available
                screen = app.primaryScreen()
                if screen:
                    sg = screen.availableGeometry()
                    sw = pix.width()
                    sh = pix.height()
                    splash.move(sg.center().x() - sw // 2, sg.center().y() - sh // 2)
                splash.show()
                app.processEvents()
                win = IDLEWindow()
                def _show_main():
                    splash.finish(win)
                    win.show()
                QtCore.QTimer.singleShot(3000, _show_main)
                sys.exit(app.exec_())
        except Exception:
            # fallback to normal startup on any error
            pass

    # default startup if splash unavailable
    win = IDLEWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
