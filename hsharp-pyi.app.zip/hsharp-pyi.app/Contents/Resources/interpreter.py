import os
from ast import *
from tokens import TokenType

class ReturnException(Exception):
    def __init__(self, value):
        self.value = value

class HSharpError(Exception):
    pass

class Environment:
    def __init__(self, parent=None):
        self.vars = {}
        self.parent = parent

    def define(self, name, value):
        self.vars[name] = value

    def assign(self, name, value):
        if name in self.vars:
            self.vars[name] = value
        elif self.parent:
            self.parent.assign(name, value)
        else:
            raise HSharpError(f"Undefined variable: '{name}'")

    def lookup(self, name):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.lookup(name)
        raise HSharpError(f"Undefined variable: '{name}'")

# --- Built-in Functions ---

def builtin_len(args):
    if len(args) != 1:
        raise HSharpError("len() takes exactly 1 argument")
    obj = args[0]
    if isinstance(obj, list):
        return len(obj)
    elif isinstance(obj, str):
        return len(obj)
    elif isinstance(obj, dict):
        return len(obj)
    else:
        raise HSharpError("len() argument must be array, dict, or string")

def builtin_push(args):
    if len(args) != 2:
        raise HSharpError("push(arr, x) takes exactly 2 arguments")
    arr, x = args
    if not isinstance(arr, list):
        raise HSharpError("First argument to push must be an array")
    arr.append(x)
    return None

def builtin_pop(args):
    if len(args) != 1:
        raise HSharpError("pop(arr) takes exactly 1 argument")
    arr = args[0]
    if not isinstance(arr, list):
        raise HSharpError("Argument to pop must be an array")
    if not arr:
        raise HSharpError("Cannot pop from empty array")
    return arr.pop()

def builtin_read_file(args):
    if len(args) != 1:
        raise HSharpError("read_file(path) takes exactly 1 argument")
    path = args[0]
    if not isinstance(path, str):
        raise HSharpError("File path must be a string")
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        raise HSharpError(f"Failed to read file '{path}': {e}")

def builtin_write_file(args):
    if len(args) != 2:
        raise HSharpError("write_file(path, content) takes exactly 2 arguments")
    path, content = args
    if not isinstance(path, str) or not isinstance(content, str):
        raise HSharpError("Arguments must be strings")
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return None
    except Exception as e:
        raise HSharpError(f"Failed to write file '{path}': {e}")

class Interpreter:
    def __init__(self, global_env=None, functions=None):
        self.global_env = global_env or Environment()
        self.functions = functions or {}
        self.interfaces = {}
        self.builtins = {
            'len': builtin_len,
            'push': builtin_push,
            'pop': builtin_pop,
            'read_file': builtin_read_file,
            'write_file': builtin_write_file,
        }

    def interpret(self, program, env=None):
        env = env or self.global_env
        try:
            for stmt in program.statements:
                result = self.execute(stmt, env)
                if isinstance(result, ReturnException):
                    return result.value
        except HSharpError as e:
            print(f"Runtime Error: {e}")
        except Exception as e:
            print(f"Unexpected error: {e}")

    def execute(self, stmt, env):
        method_name = f'visit_{type(stmt).__name__}'
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(stmt, env)

    def generic_visit(self, node, env):
        raise Exception(f'No visit_{type(node).__name__} method')

    def visit_LetStatement(self, stmt, env):
        value = self.eval_expr(stmt.value, env)
        env.define(stmt.name, value)

    def visit_PrintStatement(self, stmt, env):
        value = self.eval_expr(stmt.expr, env)
        print(value)

    def visit_ImportStatement(self, stmt, env):
        # stmt.path may be a string ("file.hto") or an Identifier (module name)
        path = stmt.path
        # import a local H# file when given a string literal
        if isinstance(path, str):
            if not path.endswith('.hto'):
                path += '.hto'
            if not os.path.exists(path):
                raise HSharpError(f"Module not found: {path}")
            with open(path, 'r', encoding='utf-8') as f:
                code = f.read()
            from lexer import Lexer
            from parser import Parser
            lexer = Lexer(code)
            parser = Parser(lexer)
            program = parser.parse()
            # run in the current env (imported names populate current env)
            sub_interpreter = Interpreter(global_env=env, functions=self.functions)
            sub_interpreter.interpret(program, env)
            # merge interfaces from imported module
            if hasattr(sub_interpreter, 'interfaces'):
                self.interfaces.update(sub_interpreter.interfaces)
        else:
            # assume Identifier: try to import a Python module of that name
            if isinstance(path, Identifier):
                modname = path.name
            else:
                raise HSharpError('Unsupported import path')
            try:
                import importlib
                mod = importlib.import_module(modname)
            except Exception as e:
                raise HSharpError(f"Failed to import Python module '{modname}': {e}")
            # wrap module into a simple H#-friendly dict exposing attributes
            proxy = {}
            for attr in dir(mod):
                if attr.startswith('_'):
                    continue
                try:
                    val = getattr(mod, attr)
                except Exception:
                    continue
                # allow functions and simple objects; leave as-is
                proxy[attr] = val
            env.define(modname, proxy)

    def visit_WhileStatement(self, stmt, env):
        while True:
            cond = self.eval_expr(stmt.condition, env)
            if not isinstance(cond, bool):
                raise HSharpError("While condition must be boolean")
            if not cond:
                break
            result = self.execute_block(stmt.body, env)
            if isinstance(result, ReturnException):
                return result

    def visit_IfStatement(self, stmt, env):
        cond = self.eval_expr(stmt.condition, env)
        if not isinstance(cond, bool):
            raise HSharpError("If condition must be boolean")
        if cond:
            return self.execute_block(stmt.consequence, env)
        elif stmt.alternative:
            return self.execute_block(stmt.alternative, env)

    def visit_ForStatement(self, stmt, env):
        iterable = self.eval_expr(stmt.iterable, env)
        loop_env = Environment(parent=env)
        if isinstance(iterable, list):
            for item in iterable:
                loop_env.define(stmt.var1, item)
                result = self.execute_block(stmt.body, loop_env)
                if isinstance(result, ReturnException):
                    return result
        elif isinstance(iterable, dict):
            for k, v in iterable.items():
                loop_env.define(stmt.var1, k)
                if stmt.var2:
                    loop_env.define(stmt.var2, v)
                result = self.execute_block(stmt.body, loop_env)
                if isinstance(result, ReturnException):
                    return result
        elif isinstance(iterable, str):
            for char in iterable:
                loop_env.define(stmt.var1, char)
                result = self.execute_block(stmt.body, loop_env)
                if isinstance(result, ReturnException):
                    return result
        else:
            raise HSharpError("Can only iterate over array, dict, or string")

    def execute_block(self, block, env):
        block_env = Environment(parent=env)
        for s in block.statements:
            result = self.execute(s, block_env)
            if isinstance(result, ReturnException):
                return result

    def visit_BlockStatement(self, stmt, env):
        return self.execute_block(stmt, env)

    def visit_ReturnStatement(self, stmt, env):
        value = self.eval_expr(stmt.expr, env)
        raise ReturnException(value)

    def visit_Function(self, stmt, env):
        self.functions[stmt.name] = stmt

    def visit_ClassDeclaration(self, stmt, env):
        # collect methods and fields, support inheritance and private fields
        methods = {}
        fields = {}
        private = []
        for s in stmt.body.statements:
            if isinstance(s, Function):
                methods[s.name] = s
            elif isinstance(s, FieldDeclaration):
                # evaluate default in global env (only simple literals expected)
                fields[s.name] = self.eval_expr(s.value, self.global_env)
                if s.is_private:
                    private.append(s.name)
        class_obj = {'name': stmt.name, 'methods': methods, 'fields': fields, 'private': private}
        # handle inheritance by merging base if present
        if getattr(stmt, 'base', None):
            base_name = stmt.base
            base = None
            try:
                base = self.functions.get(base_name) or self.global_env.lookup(base_name)
            except HSharpError:
                base = None
            if not base:
                raise HSharpError(f"Base class not found: {base_name}")
            # merge base methods/fields/private
            merged_methods = {}
            merged_fields = {}
            merged_private = []
            if isinstance(base, dict):
                merged_methods.update(base.get('methods', {}))
                merged_fields.update(base.get('fields', {}))
                merged_private.extend(base.get('private', []))
            merged_methods.update(methods)
            merged_fields.update(fields)
            merged_private.extend(private)
            class_obj['methods'] = merged_methods
            class_obj['fields'] = merged_fields
            class_obj['private'] = merged_private

        self.functions[stmt.name] = class_obj
        # verify interface implementations
        for iface_name in getattr(stmt, 'implements', []) or []:
            iface = self.interfaces.get(iface_name)
            if iface is None:
                raise HSharpError(f"Interface '{iface_name}' not found for class '{stmt.name}'")
            # iface.methods contains merged methods from bases; entries may be Function nodes (with body for defaults)
            for mname, sig in iface.get('methods', {}).items():
                found = class_obj['methods'].get(mname)
                if not found:
                    # if interface provides a default implementation (Function with body), copy it into class
                    if isinstance(sig, Function) and sig.body is not None:
                        class_obj['methods'][mname] = sig
                        continue
                    raise HSharpError(f"Class '{stmt.name}' does not implement interface method '{mname}' from '{iface_name}'")
                # check arity
                if len(found.params) != len(sig.params):
                    raise HSharpError(f"Method '{mname}' in class '{stmt.name}' has wrong arity for interface '{iface_name}'")

    def visit_CallExpression(self, expr, env):
        args = [self.eval_expr(arg, env) for arg in expr.args]
        # function can be Identifier or MemberExpression or other
        if isinstance(expr.func, Identifier):
            name = expr.func.name
            if name in self.builtins:
                return self.builtins[name](args)
            if name not in self.functions:
                raise HSharpError(f"Function '{name}' not defined")
            func = self.functions[name]
            if isinstance(func, dict) and 'methods' in func:
                raise HSharpError(f"'{name}' is a class, cannot call directly")
            if len(args) != len(func.params):
                raise HSharpError(f"Function '{name}' expects {len(func.params)} arguments, got {len(args)}")
            call_env = Environment(parent=self.global_env)
            for param, arg in zip(func.params, args):
                call_env.define(param, arg)
            try:
                self.visit_BlockStatement(func.body, call_env)
            except ReturnException as e:
                return e.value
            return None
        elif isinstance(expr.func, MemberExpression):
            # method call: evaluate left to get instance
            left = self.eval_expr(expr.func.left, env)
            attr = expr.func.name
            if not isinstance(left, dict) or '__class__' not in left:
                raise HSharpError('Left side of member call is not an object')
            class_obj = left['__class__']
            methods = class_obj.get('methods', {})
            if attr not in methods:
                # may be callable field
                val = left.get(attr)
                if callable(val):
                    return val(*args)
                raise HSharpError(f"Attribute '{attr}' not found on instance")
            method = methods[attr]
            call_env = Environment(parent=self.global_env)
            call_env.define('self', left)
            if len(args) != len(method.params):
                raise HSharpError(f"Method '{attr}' expects {len(method.params)} arguments, got {len(args)}")
            for param, arg in zip(method.params, args):
                call_env.define(param, arg)
            try:
                self.visit_BlockStatement(method.body, call_env)
            except ReturnException as e:
                return e.value
            return None
        else:
            raise HSharpError('Unsupported call expression')

    def visit_ArrayLiteral(self, expr, env):
        return [self.eval_expr(e, env) for e in expr.elements]

    def visit_DictLiteral(self, expr, env):
        d = {}
        for key_expr, val_expr in expr.pairs:
            key = self.eval_expr(key_expr, env)
            if not isinstance(key, (str, int)):
                raise HSharpError("Dictionary keys must be strings or integers")
            val = self.eval_expr(val_expr, env)
            d[key] = val
        return d

    def visit_IndexExpression(self, expr, env):
        left = self.eval_expr(expr.left, env)
        index = self.eval_expr(expr.index, env)
        if isinstance(left, list):
            if not isinstance(index, int):
                raise HSharpError("Array index must be integer")
            if index < 0 or index >= len(left):
                raise HSharpError("Array index out of bounds")
            return left[index]
        elif isinstance(left, str):
            if not isinstance(index, int):
                raise HSharpError("String index must be integer")
            if index < 0 or index >= len(left):
                raise HSharpError("String index out of bounds")
            return left[index]
        elif isinstance(left, dict):
            if index not in left:
                raise HSharpError(f"Key '{index}' not found in dictionary")
            return left[index]
        else:
            raise HSharpError("Can only index arrays, strings, or dictionaries")

    def visit_AssignmentIndex(self, stmt, env):
        arr = self.eval_expr(stmt.array, env)
        index = self.eval_expr(stmt.index, env)
        value = self.eval_expr(stmt.value, env)
        if isinstance(arr, list):
            if not isinstance(index, int):
                raise HSharpError("Array index must be integer")
            if index < 0 or index >= len(arr):
                raise HSharpError("Array index out of bounds")
            arr[index] = value
        elif isinstance(arr, dict):
            arr[index] = value
        else:
            raise HSharpError("Can only assign to array or dictionary elements")
        return value

    def visit_AssignmentMember(self, stmt, env):
        obj = self.eval_expr(stmt.left, env)
        if not isinstance(obj, dict) or '__class__' not in obj:
            raise HSharpError('Left side of member assignment is not an object')
        value = self.eval_expr(stmt.value, env)
        obj[stmt.name] = value
        return value

    def visit_InterfaceDeclaration(self, stmt, env):
        # store interface signatures and default implementations; support interface inheritance
        methods = {}
        for s in stmt.body.statements:
            if isinstance(s, Function):
                methods[s.name] = s
            else:
                raise HSharpError('Invalid member in interface')

        # merge bases
        merged_methods = {}
        for base_name in getattr(stmt, 'bases', []) or []:
            base_iface = self.interfaces.get(base_name)
            if base_iface is None:
                raise HSharpError(f"Interface base '{base_name}' not found for interface '{stmt.name}'")
            merged_methods.update(base_iface.get('methods', {}))
        # then overlay this interface's methods
        merged_methods.update(methods)

        iface = {'name': stmt.name, 'methods': merged_methods, 'body': stmt.body, 'bases': getattr(stmt, 'bases', []) or []}
        self.interfaces[stmt.name] = iface

    def eval_expr(self, expr, env):
        if isinstance(expr, Identifier):
            return env.lookup(expr.name)
        elif isinstance(expr, NumberLiteral):
            return expr.value
        elif isinstance(expr, StringLiteral):
            return expr.value
        elif isinstance(expr, BooleanLiteral):
            return expr.value
        elif isinstance(expr, ArrayLiteral):
            return self.visit_ArrayLiteral(expr, env)
        elif isinstance(expr, DictLiteral):
            return self.visit_DictLiteral(expr, env)
        elif isinstance(expr, IndexExpression):
            return self.visit_IndexExpression(expr, env)
        elif isinstance(expr, BinaryOp):
            left = self.eval_expr(expr.left, env)
            right = self.eval_expr(expr.right, env)
            op = expr.op
            if op == TokenType.PLUS:
                if isinstance(left, str) or isinstance(right, str):
                    return str(left) + str(right)
                if isinstance(left, list) and isinstance(right, list):
                    return left + right
                self._ensure_number(left, right)
                return left + right
            elif op == TokenType.MINUS:
                self._ensure_number(left, right)
                return left - right
            elif op == TokenType.STAR:
                self._ensure_number(left, right)
                return left * right
            elif op == TokenType.SLASH:
                self._ensure_number(left, right)
                if right == 0:
                    raise HSharpError("Division by zero")
                return left // right
            elif op == TokenType.EQEQ:
                return left == right
            elif op == TokenType.BANGEQ:
                return left != right
            elif op == TokenType.GT:
                self._ensure_comparable(left, right)
                return left > right
            elif op == TokenType.LT:
                self._ensure_comparable(left, right)
                return left < right
            elif op == TokenType.GTE:
                self._ensure_comparable(left, right)
                return left >= right
            elif op == TokenType.LTE:
                self._ensure_comparable(left, right)
                return left <= right
            elif op == TokenType.AND:
                if not isinstance(left, bool):
                    raise HSharpError("Operands of 'and' must be boolean")
                if not left:
                    return False
                if not isinstance(right, bool):
                    raise HSharpError("Operands of 'and' must be boolean")
                return right
            elif op == TokenType.OR:
                if not isinstance(left, bool):
                    raise HSharpError("Operands of 'or' must be boolean")
                if left:
                    return True
                if not isinstance(right, bool):
                    raise HSharpError("Operands of 'or' must be boolean")
                return right
            else:
                raise HSharpError(f"Unknown operator: {op}")
        elif isinstance(expr, UnaryOp):
            if expr.op == TokenType.NOT:
                val = self.eval_expr(expr.operand, env)
                if not isinstance(val, bool):
                    raise HSharpError("'not' operand must be boolean")
                return not val
            else:
                raise HSharpError(f"Unknown unary operator: {expr.op}")
        elif isinstance(expr, CallExpression):
            return self.visit_CallExpression(expr, env)
        elif isinstance(expr, MemberExpression):
            left = self.eval_expr(expr.left, env)
            if isinstance(left, dict) and '__class__' in left:
                # return field value if exists
                if expr.name in left:
                    return left[expr.name]
                # fallback to class default field
                class_obj = left['__class__']
                fields = class_obj.get('fields', {})
                if expr.name in fields:
                    return fields[expr.name]
                # methods are not returned directly here
                raise HSharpError(f"Attribute '{expr.name}' not found on instance")
            # property access on dict-like
            if isinstance(left, dict):
                if expr.name in left:
                    return left[expr.name]
            raise HSharpError(f"Cannot access attribute '{expr.name}' on non-object")
        else:
            raise HSharpError(f"Unknown expression: {expr}")

    def _ensure_number(self, a, b):
        if not isinstance(a, int) or not isinstance(b, int):
            raise HSharpError("Operands must be numbers")

    def _ensure_comparable(self, a, b):
        if type(a) != type(b):
            raise HSharpError("Cannot compare different types")
        if not isinstance(a, (int, str)):
            raise HSharpError("Can only compare numbers or strings")