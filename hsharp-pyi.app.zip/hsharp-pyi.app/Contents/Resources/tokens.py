from enum import Enum

class TokenType(Enum):
    LET = 'LET'
    FN = 'FN'
    RETURN = 'RETURN'
    WHILE = 'WHILE'
    IF = 'IF'
    ELSE = 'ELSE'
    FOR = 'FOR'
    IN = 'IN'
    PRINT = 'PRINT'
    IMPORT = 'IMPORT'
    CLASS = 'CLASS'
    NEW = 'NEW'
    INTERFACE = 'INTERFACE'
    IMPLEMENTS = 'IMPLEMENTS'
    EXTENDS = 'EXTENDS'
    PRIVATE = 'PRIVATE'

    IDENTIFIER = 'IDENTIFIER'
    NUMBER = 'NUMBER'
    STRING = 'STRING'
    BOOL = 'BOOL'

    PLUS = 'PLUS'
    MINUS = 'MINUS'
    STAR = 'STAR'
    SLASH = 'SLASH'

    EQ = 'EQ'          # =
    EQEQ = 'EQEQ'      # ==
    BANGEQ = 'BANGEQ'  # !=
    GT = 'GT'
    LT = 'LT'
    GTE = 'GTE'
    LTE = 'LTE'

    LPAREN = 'LPAREN'
    RPAREN = 'RPAREN'
    LBRACE = 'LBRACE'
    RBRACE = 'RBRACE'
    LBRACKET = 'LBRACKET'
    RBRACKET = 'RBRACKET'

    COLON = 'COLON'    # :
    COMMA = 'COMMA'
    SEMI = 'SEMI'
    DOT = 'DOT'
    AND = 'AND'
    OR = 'OR'
    NOT = 'NOT'
    EOF = 'EOF'